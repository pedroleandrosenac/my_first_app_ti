import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CreateCandidateScreen extends StatelessWidget {
  const CreateCandidateScreen({super.key});

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        appBar: AppBar(
          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
          title: Text("Lista de candidatos"),
        ),
        body: Text("Formulário de Cadastro"),
    );

  }
}
